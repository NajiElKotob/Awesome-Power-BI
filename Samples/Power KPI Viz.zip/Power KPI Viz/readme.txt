https://appsource.microsoft.com/en-us/product/power-bi-visuals/WA104381083?tab=Overview
https://www.youtube.com/watch?v=IvfIP3E6-1Q&feature=youtu.be
https://powerbi.microsoft.com/en-us/blog/balanced-scorecards/
